<?php $__env->startSection('title', isset($cover) ? 'Edit Cover' : 'Tambah Cover'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3><?php echo e(isset($cover) ? 'Edit Cover' : 'Tambah Cover'); ?></h3>
    </div>
    <div class="page-content">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show">
                <div class="d-flex align-items-center">
                    <div class="font-35 text-white"><i class='bx bxs-message-square-x'></i></div>
                    <div class="ms-3">
                        <ul class="mb-0 text-white">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('message')): ?>
            <div
                class="alert alert-<?php echo e(session('message_type') ?? 'success'); ?> border-0 bg-<?php echo e(session('message_type') ?? 'success'); ?> alert-dismissible fade show">
                <div class="d-flex align-items-center">
                    <div class="font-35 text-white"><i class='bx bxs-check-circle'></i></div>
                    <div class="ms-3">
                        <h6 class="mb-0 text-white"><?php echo e(session('message_title') ?? 'Success'); ?></h6>
                        <div class="text-white"><?php echo e(session('message')); ?></div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                    aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form id="coverForm"
                    action="<?php echo e(isset($cover) ? route('kelola_data.cover.update', Crypt::encrypt($cover->id)) : route('kelola_data.cover.store')); ?>"
                    method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($cover)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3" dir="rtl">
                                <label for="nama_arab" style="text-align: right; display: block;">نوع تجليد</label>
                                <input type="text" name="nama_arab" id="nama_arab" class="form-control"
                                    value="<?php echo e(old('nama_arab', $cover->nama_arab ?? '')); ?>"
                                    placeholder="Masukkan nama cover dalam bahasa Arab" required dir="rtl"
                                    style="text-align: right;">
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="nama_indonesia">Nama cover (Indonesia)</label>
                                <input type="text" name="nama_indonesia" id="nama_indonesia" class="form-control"
                                    value="<?php echo e(old('nama_indonesia', $cover->nama_indonesia ?? '')); ?>"
                                    placeholder="Masukkan nama cover dalam bahasa Indonesia" required>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="<?php echo e(route('kelola_data.cover.index')); ?>" class="btn btn-secondary">
                            <i class="bx bx-arrow-back"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bx bx-save"></i> <?php echo e(isset($cover) ? 'Update' : 'Simpan'); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/kelola_data/cover/create.blade.php ENDPATH**/ ?>