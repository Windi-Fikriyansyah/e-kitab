<?php $__env->startSection('title', 'Dashboard'); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-mantap\resources\views/dashboard.blade.php ENDPATH**/ ?>