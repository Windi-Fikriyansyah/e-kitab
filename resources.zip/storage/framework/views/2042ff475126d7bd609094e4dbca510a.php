<?php $__env->startSection('title', isset($ukuran) ? 'Edit Ukuran' : 'Tambah Ukuran'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3><?php echo e(isset($ukuran) ? 'Edit Ukuran' : 'Tambah Ukuran'); ?></h3>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('kelola_data.ukuran.index')); ?>">Data Ukuran</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(isset($ukuran) ? 'Edit' : 'Tambah'); ?>

                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="page-content">
        <section class="section">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show">
                    <div class="d-flex align-items-center">
                        <div class="font-35 text-white"><i class='bx bxs-message-square-x'></i></div>
                        <div class="ms-3">
                            <h6 class="mb-1 text-white">Error Validasi</h6>
                            <ul class="mb-0 text-white">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(session('message')): ?>
                <div
                    class="alert alert-<?php echo e(session('message_type') ?? 'success'); ?> border-0 bg-<?php echo e(session('message_type') ?? 'success'); ?> alert-dismissible fade show">
                    <div class="d-flex align-items-center">
                        <div class="font-35 text-white"><i class='bx bxs-check-circle'></i></div>
                        <div class="ms-3">
                            <h6 class="mb-0 text-white"><?php echo e(session('message_title') ?? 'Success'); ?></h6>
                            <div class="text-white"><?php echo e(session('message')); ?></div>
                        </div>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Form Ukuran</h4>
                </div>
                <div class="card-body">
                    <form id="ukuranForm"
                        action="<?php echo e(isset($ukuran) ? route('kelola_data.ukuran.update', Crypt::encrypt($ukuran->id)) : route('kelola_data.ukuran.store')); ?>"
                        method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($ukuran)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group mb-3">
                                    <label for="ukuran" class="form-label">Nama Ukuran</label>
                                    <input type="text" name="ukuran" id="ukuran" class="form-control"
                                        value="<?php echo e(old('ukuran', $ukuran->ukuran ?? '')); ?>" required>
                                    <div class="form-text">Masukkan nama ukuran produk</div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="<?php echo e(route('kelola_data.ukuran.index')); ?>" class="btn btn-light-secondary">
                                <i class="bx bx-arrow-back"></i> Kembali
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="bx bx-save"></i> <?php echo e(isset($ukuran) ? 'Update' : 'Simpan'); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/kelola_data/ukuran/create.blade.php ENDPATH**/ ?>