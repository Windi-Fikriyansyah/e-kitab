<?php $__env->startSection('title', isset($testimoni) ? 'Edit Testimoni' : 'Tambah Testimoni'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3><?php echo e(isset($testimoni) ? 'Edit Testimoni' : 'Tambah Testimoni'); ?></h3>
    </div>
    <div class="page-content">

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show">
                <ul class="mb-0 text-white">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <?php if(session('message')): ?>
            <div
                class="alert alert-<?php echo e(session('message_type') ?? 'success'); ?> border-0 bg-<?php echo e(session('message_type') ?? 'success'); ?> alert-dismissible fade show">
                <div class="text-white">
                    <strong><?php echo e(session('message_title') ?? 'Success'); ?>:</strong> <?php echo e(session('message')); ?>

                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form
                    action="<?php echo e(isset($testimoni) ? route('pengaturan_web.testimoni.update', Crypt::encrypt($testimoni->id)) : route('pengaturan_web.testimoni.store')); ?>"
                    method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($testimoni)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="row">
                        
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="nama_customer">Nama Customer</label>
                                <input type="text" name="nama_customer" id="nama_customer" class="form-control"
                                    value="<?php echo e(old('nama_customer', $testimoni->nama_customer ?? '')); ?>"
                                    placeholder="Masukkan nama customer" required>
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="caption">Caption</label>
                                <input type="text" name="caption" id="caption" class="form-control"
                                    value="<?php echo e(old('caption', $testimoni->caption ?? '')); ?>"
                                    placeholder="Masukkan caption testimoni" required>
                            </div>
                        </div>
                    </div>

                    
                    <div class="form-group mb-3">
                        <label for="foto_unboxing">Foto Unboxing</label>
                        <input type="file" name="foto_unboxing" id="foto_unboxing" class="form-control"
                            <?php echo e(isset($testimoni) ? '' : 'required'); ?>>
                        <?php if(isset($testimoni) && $testimoni->foto_unboxing): ?>
                            <div class="mt-2">
                                <img src="<?php echo e(asset('storage/testimoni/' . $testimoni->foto_unboxing)); ?>" class="logo-img"
                                    alt="Foto Unboxing">
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="d-flex justify-content-between mt-4">
                        <a href="<?php echo e(route('pengaturan_web.testimoni.index')); ?>" class="btn btn-secondary">
                            <i class="bx bx-arrow-back"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bx bx-save"></i> <?php echo e(isset($testimoni) ? 'Update' : 'Simpan'); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/pengaturan_web/testimoni/create.blade.php ENDPATH**/ ?>