<?php $__env->startSection('title', 'Pengaturan Landing Page - Hero Section'); ?>
<?php $__env->startSection('content'); ?>
    <div aria-live="polite" aria-atomic="true" class="position-relative">
        <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999">
            <?php if(session('success')): ?>
                <div class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive"
                    aria-atomic="true" id="successToast">
                    <div class="d-flex">
                        <div class="toast-body">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo e(session('success')); ?>

                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                            aria-label="Close"></button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="toast align-items-center text-white bg-danger border-0" role="alert" aria-live="assertive"
                    aria-atomic="true" id="errorToast">
                    <div class="d-flex">
                        <div class="toast-body">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo e(session('error')); ?>

                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                            aria-label="Close"></button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="toast align-items-center text-white bg-danger border-0" role="alert" aria-live="assertive"
                    aria-atomic="true" id="validationToast">
                    <div class="d-flex">
                        <div class="toast-body">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Terdapat kesalahan dalam pengisian form. Silakan periksa kembali.
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                            aria-label="Close"></button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="mb-0"><?php echo e(isset($landing) ? 'Edit' : 'Tambah'); ?> Pengaturan Hero Section</h5>
                        <small class="text-muted float-end">Kelola konten hero section halaman utama</small>
                    </div>
                    <div class="card-body">
                        <form
                            action="<?php echo e(isset($landing) ? route('pengaturan_web.hero.update', $landing->id) : route('pengaturan_web.hero.store')); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($landing)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>

                            <div class="mt-4">


                                <!-- Gambar Slider -->
                                <h6 class="mb-3 text-primary mt-4">Gambar Slider</h6>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label">Gambar 1</label>
                                    <div class="col-sm-10">
                                        <input type="file" name="hero_image_1"
                                            class="form-control image-upload <?php $__errorArgs = ['hero_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            accept="image/*" data-preview="hero_image_1_preview" />
                                        <div class="image-preview mt-2" id="hero_image_1_preview">
                                            <?php if(isset($landing) && $landing->hero_image_1): ?>
                                                <img src="<?php echo e(asset('storage/' . $landing->hero_image_1)); ?>"
                                                    class="img-thumbnail" style="max-height: 150px;">
                                                <small class="text-muted d-block">Current:
                                                    <?php echo e(basename($landing->hero_image_1)); ?></small>
                                            <?php endif; ?>
                                        </div>
                                        <?php $__errorArgs = ['hero_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label">Gambar 2</label>
                                    <div class="col-sm-10">
                                        <input type="file" name="hero_image_2"
                                            class="form-control image-upload <?php $__errorArgs = ['hero_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            accept="image/*" data-preview="hero_image_2_preview" />
                                        <div class="image-preview mt-2" id="hero_image_2_preview">
                                            <?php if(isset($landing) && $landing->hero_image_2): ?>
                                                <img src="<?php echo e(asset('storage/' . $landing->hero_image_2)); ?>"
                                                    class="img-thumbnail" style="max-height: 150px;">
                                                <small class="text-muted d-block">Current:
                                                    <?php echo e(basename($landing->hero_image_2)); ?></small>
                                            <?php endif; ?>
                                        </div>
                                        <?php $__errorArgs = ['hero_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Submit Buttons -->
                            <div class="row justify-content-end mt-4">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(isset($landing) ? 'Update' : 'Simpan'); ?> Pengaturan
                                    </button>
                                    <a href="<?php echo e(route('pengaturan_web.hero.index')); ?>"
                                        class="btn btn-secondary">Kembali</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .text-primary {
            color: #007bff !important;
        }

        .image-preview {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .image-preview img {
            max-height: 150px;
            margin-bottom: 5px;
            border: 1px solid #dee2e6;
            border-radius: 4px;
        }

        .toast {
            min-width: 300px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }

        .toast-body {
            padding: 0.75rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            // Image preview functionality
            function readURL(input, previewId) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#' + previewId).html(
                            '<img src="' + e.target.result +
                            '" class="img-thumbnail" style="max-height: 150px;">' +
                            '<button type="button" class="btn btn-sm btn-danger remove-preview mt-2" data-preview="' +
                            previewId + '">' +
                            '<i class="fas fa-times"></i> Hapus Preview' +
                            '</button>'
                        );
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            // Handle image upload and preview
            $('.image-upload').change(function() {
                var previewId = $(this).data('preview');
                readURL(this, previewId);
            });

            // Remove preview image
            $(document).on('click', '.remove-preview', function() {
                var previewId = $(this).data('preview');
                $('#' + previewId).html('');
                $('input[data-preview="' + previewId + '"]').val('');
            });
        });

        <?php if(session('success')): ?>
            var successToast = new bootstrap.Toast(document.getElementById('successToast'));
            successToast.show();
        <?php endif; ?>

        <?php if(session('error')): ?>
            var errorToast = new bootstrap.Toast(document.getElementById('errorToast'));
            errorToast.show();
        <?php endif; ?>

        <?php if($errors->any()): ?>
            var validationToast = new bootstrap.Toast(document.getElementById('validationToast'));
            validationToast.show();
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/pengaturan/index.blade.php ENDPATH**/ ?>