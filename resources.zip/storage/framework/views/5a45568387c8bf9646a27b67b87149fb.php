<?php $__env->startSection('title', 'Dashboard'); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kasir\resources\views/home.blade.php ENDPATH**/ ?>