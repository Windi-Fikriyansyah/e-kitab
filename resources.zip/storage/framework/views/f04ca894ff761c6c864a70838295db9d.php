<?php $__env->startSection('title', isset($social) ? 'Edit Link Social Media' : 'Tambah Link Social Media'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3><?php echo e(isset($social) ? 'Edit Link Social Media' : 'Tambah Link Social Media'); ?></h3>
    </div>
    <div class="page-content">

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show">
                <ul class="mb-0 text-white">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        
        <?php if(session('message')): ?>
            <div
                class="alert alert-<?php echo e(session('message_type') ?? 'success'); ?> border-0 bg-<?php echo e(session('message_type') ?? 'success'); ?> alert-dismissible fade show">
                <div class="text-white">
                    <strong><?php echo e(session('message_title') ?? 'Success'); ?>:</strong> <?php echo e(session('message')); ?>

                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form
                    action="<?php echo e(isset($social)
                        ? route('pengaturan_web.link_social.update', Crypt::encrypt($social->id))
                        : route('pengaturan_web.link_social.store')); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($social)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="row">
                        
                        <div class="col-md-6 mb-3">
                            <label for="facebook">Facebook</label>
                            <input type="url" name="facebook" id="facebook" class="form-control"
                                value="<?php echo e(old('facebook', $social->facebook ?? '')); ?>"
                                placeholder="https://facebook.com/username">
                        </div>

                        
                        <div class="col-md-6 mb-3">
                            <label for="instagram">Instagram</label>
                            <input type="url" name="instagram" id="instagram" class="form-control"
                                value="<?php echo e(old('instagram', $social->instagram ?? '')); ?>"
                                placeholder="https://instagram.com/username">
                        </div>

                        
                        <div class="col-md-6 mb-3">
                            <label for="twitter">Twitter</label>
                            <input type="url" name="twitter" id="twitter" class="form-control"
                                value="<?php echo e(old('twitter', $social->twitter ?? '')); ?>"
                                placeholder="https://twitter.com/username">
                        </div>

                        
                        <div class="col-md-6 mb-3">
                            <label for="tiktok">TikTok</label>
                            <input type="url" name="tiktok" id="tiktok" class="form-control"
                                value="<?php echo e(old('tiktok', $social->tiktok ?? '')); ?>"
                                placeholder="https://tiktok.com/@username">
                        </div>

                        
                        <div class="col-md-6 mb-3">
                            <label for="telegram">Telegram</label>
                            <input type="url" name="telegram" id="telegram" class="form-control"
                                value="<?php echo e(old('telegram', $social->telegram ?? '')); ?>" placeholder="https://t.me/username">
                        </div>

                        
                        <div class="col-md-6 mb-3">
                            <label for="google_maps">Google Maps</label>
                            <input type="url" name="google_maps" id="google_maps" class="form-control"
                                value="<?php echo e(old('google_maps', $social->google_maps ?? '')); ?>"
                                placeholder="https://goo.gl/maps/xxxx">
                        </div>

                        
                        <div class="col-md-12 mb-3">
                            <label for="youtube">YouTube</label>
                            <input type="url" name="youtube" id="youtube" class="form-control"
                                value="<?php echo e(old('youtube', $social->youtube ?? '')); ?>"
                                placeholder="https://youtube.com/channel/xxxx">
                        </div>
                    </div>

                    
                    <div class="d-flex justify-content-between mt-4">
                        <a href="<?php echo e(route('pengaturan_web.link_social.index')); ?>" class="btn btn-secondary">
                            <i class="bx bx-arrow-back"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bx bx-save"></i> <?php echo e(isset($social) ? 'Update' : 'Simpan'); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/pengaturan_web/link_social/create.blade.php ENDPATH**/ ?>