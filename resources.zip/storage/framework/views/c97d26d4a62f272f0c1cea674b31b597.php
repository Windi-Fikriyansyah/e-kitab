<table border="1">
    <thead>
        <tr>
            <th colspan="6" style="text-align:center; font-weight:bold; font-size:16px;">
                LAPORAN PENGELUARAN
            </th>
        </tr>
        <tr>
            <th colspan="6" style="text-align:center;">
                Periode: <?php echo e(\Carbon\Carbon::parse($tanggalAwal)->format('d/m/Y')); ?> -
                <?php echo e(\Carbon\Carbon::parse($tanggalAkhir)->format('d/m/Y')); ?>

                <?php if($kategori): ?>
                    (Kategori: <?php echo e($kategori); ?>)
                <?php endif; ?>
            </th>
        </tr>
        <tr>
            <th style="background-color:#e5e5e5;">Tanggal</th>
            <th style="background-color:#e5e5e5;">Kategori</th>
            <th style="background-color:#e5e5e5;">Deskripsi</th>
            <th style="background-color:#e5e5e5;">Nominal</th>
            <th style="background-color:#e5e5e5;">Metode Bayar</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($row->tanggal)->format('d/m/Y')); ?></td>
                <td><?php echo e($row->kategori); ?></td>
                <td><?php echo e($row->deskripsi); ?></td>
                <td>Rp <?php echo e(number_format($row->nominal, 0, ',', '.')); ?></td>
                <td><?php echo e($row->metode_bayar); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr style="font-weight:bold; background-color:#f2f2f2;">
            <td colspan="3" style="text-align:right;">TOTAL</td>
            <td>Rp <?php echo e(number_format($totalNominal, 0, ',', '.')); ?></td>
            <td colspan="2"></td>
        </tr>
    </tbody>
</table>
<?php /**PATH D:\e-arab\resources\views/laporan/pengeluaran/export.blade.php ENDPATH**/ ?>