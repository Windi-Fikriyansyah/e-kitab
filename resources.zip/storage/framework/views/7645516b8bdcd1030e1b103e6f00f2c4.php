<?php $__env->startSection('title', 'Verifikasi Admin Sertifikat'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Verifikasi Admin Sertifikat</h3>
    </div>
    <div class="page-content">
        <?php if(session('message')): ?>
            <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card radius-10">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <div>
                        <h5 class="card-title">Sertifikat</h5>
                    </div>

                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle mb-0" id="sertifikat" style="width: 100%">
                        <thead>
                            <tr>
                                <th>Nomor Surat</th>
                                <th>Nomor Arsip Dokumen</th>
                                <th>Nomor Sertifikat</th>
                                <th>SKPD</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="verifModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="verifModalLabel">Verifikasi Peminjaman Sertifikat</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Tanggal Verifikasi</label>
                    <div class="col-sm-4">
                        <input class="form-control" id="tanggalVerifAdmin" name="tanggalVerifAdmin" type="date">
                    </div>
                    <label class="col-sm-2 col-form-label">Tanggal Ver. Operator</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="tanggalVerifikasiOperator"
                            name="tanggalVerifikasiOperator" type="text" readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Nomor Surat</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="nomorSurat" name="nomorSurat" type="text"
                            readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Tanggal Pinjam</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="tanggalPinjam" name="tanggalPinjam" type="text"
                            readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Nomor Arsip Dokumen</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="nomorRegister" name="nomorRegister" type="text"
                            readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nomor Sertifikat</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="nomorSertifikat" name="nomorSertifikat" type="text"
                            readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">NIB</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="NIB" name="NIB" type="text"
                            readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nama KSBTGT</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="namaKsbtgn" name="namaKsbtgn" type="text"
                            readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Luas</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="luas" name="luas" type="text" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nip KSBTGT</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="nipKsbtgn" name="nipKsbtgn" type="text" readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">kode SKPD</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="kodeSkpd" name="kodeSkpd" type="text"
                            readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">No Telp KSBTGT</label>
                    <div class="col-sm-4">
                        <input class="form-control readonlyInput" id="noTelpKsbtgn" name="noTelpKsbtgn" type="text"
                            readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Peruntukan</label>
                    <div class="col-sm-10">
                        <textarea class="form-control readonlyInput" id="peruntukan" name="peruntukan" type="text" readonly></textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12 text-center">
                        <button type="button" class="btn btn-success ms-1" id="VerifOperator">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Verifikasi</span>
                        </button>
                        <button type="button" class="btn btn-danger ms-1" id="TolakVerif">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Tolak Peminjaman</span>
                        </button>
                        <button type="button" class="btn btn-danger ms-1 d-none" id="BatalkanVerif">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Batal Verifikasi</span>
                        </button>
                    </div>

                </div>
                <div class="row mb-3">
                    <div class="col-sm-12">
                        <iframe style="width: 100%;height:100vh" id="filePengajuan"></iframe>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <style>
        .right-gap {
            margin-right: 10px
        }
    </style>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#sertifikat').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('verifikasi_admin.sertifikat.load')); ?>",
                    type: "POST",
                    data: function(data) {
                        data.search = data.search.value;
                    }
                },
                createdRow: function(row, data, index) {
                    if (data.statusTolak == "1") {
                        $(row).css("background-color", "#ff0e0e");
                    } else {
                        $(row).css("background-color", "");
                    }
                },
                pageLength: 10,
                searching: true,
                columns: [
                {
                    data: 'nomorSurat',
                    name: 'nomorSurat'
                },
                {
                    data: 'nomorRegister',
                    name: 'nomorRegister'
                },
                {
                    data: 'nomorSertifikat',
                    name: 'nomorSertifikat'
                },
                {
                    data: 'namaSkpd',
                    name: 'namaSkpd'
                },
                {
                    data: 'aksi',
                    className: 'text-center'
                }
            ]
            });
        });

        function verif(nomorSurat) {
            $.ajax({
                url: '<?php echo e(route("verifikasi_admin.sertifikat.verif")); ?>',
                type: 'POST',
                data: {
                    nomorSurat: nomorSurat,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    $('#tanggalVerifAdmin').val(data.tanggalVerifAdmin);
                    $('#tanggalVerifikasiOperator').val(data.tanggalVerifikasiOperator);
                    $('#nomorSurat').val(data.nomorSurat);
                    $('#tanggalPinjam').val(data.tanggalPinjam);
                    $('#nomorRegister').val(data.nomorRegister);
                    $('#nomorSertifikat').val(data.nomorSertifikat);
                    $('#NIB').val(data.NIB);
                    $('#pemegangHak').val(data.pemegangHak);
                    $('#tanggal').val(data.tanggal);
                    $('#pemegangHak').val(data.pemegangHak);
                    $('#luas').val(data.luas);
                    $('#peruntukan').val(data.peruntukan);
                    $('#namaKsbtgn').val(data.namaKsbtgn);
                    $('#nipKsbtgn').val(data.nipKsbtgn);
                    $('#kodeSkpd').val(data.kodeSkpd);
                    $('#noTelpKsbtgn').val(data.noTelpKsbtgn);

                    if(data.statusTolak == 1){
                        $('#VerifOperator').addClass('d-none');
                        $('#BatalkanVerif').addClass('d-none');
                        $('#TolakVerif').addClass('d-none');
                    }
                    else if (data.statusVerifPenyelia == 1) {
                        $('#VerifOperator').addClass('d-none');
                        $('#BatalkanVerif').addClass('d-none');
                        $('#TolakVerif').addClass('d-none');
                    } else if (data.statusVerifAdmin == 1) {
                        $('#VerifOperator').addClass('d-none');
                        $('#BatalkanVerif').removeClass('d-none');
                        $('#TolakVerif').addClass('d-none');
                    } else {
                        $('#VerifOperator').removeClass('d-none');
                        $('#TolakVerif').removeClass('d-none');
                        $('#BatalkanVerif').addClass('d-none');
                    }

                    const filePath = `storage/images/Peminjaman/Sertifikat/${data.kodeSkpd}/${data.file}`;
                    if (data.file) {
                        $('#filePengajuan').attr('src', `<?php echo e(asset('${filePath}')); ?>`);
                    } else {
                        $('#filePengajuan').attr('src', '');
                    }

                    $('#verifModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('Terjadi kesalahan:', error);
                }
            });
        }

        $('#VerifOperator').on('click', function() {
            var nomorSurat = $('#nomorSurat').val();
            var tanggalPinjam = $('#tanggalPinjam').val();
            var tanggalVerifAdmin = $('#tanggalVerifAdmin').val();
            var tanggalVerifikasiOperator = $('#tanggalVerifikasiOperator').val();
            if (!tanggalVerifAdmin) {
                    Swal.fire({
                        title: "Peringatan!",
                        text: "Silahkan pilih tanggal verifikasi!",
                        icon: "warning"
                    });
                    return;  // Hentikan eksekusi jika tanggal belum dipilih
                }
                if (tanggalVerifAdmin < tanggalPinjam) {
                    Swal.fire({
                        title: "Peringatan!",
                        text: "Tanggal verifikasi tidak boleh lebih kecil dari tanggal pinjam!",
                        icon: "warning"
                    });
                    return;
                }

                if (tanggalVerifAdmin < tanggalVerifikasiOperator) {
                    Swal.fire({
                        title: "Peringatan!",
                        text: "Tanggal verifikasi tidak boleh lebih kecil dari tanggal Verif Operator!",
                        icon: "warning"
                    });
                    return;
                }
            $.ajax({
                url: '<?php echo e(route("verifikasi_admin.sertifikat.verifikasi_admin")); ?>',
                type: 'POST',
                data: {
                    nomorSurat: nomorSurat,
                    tanggalVerifAdmin: tanggalVerifAdmin,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    $('#VerifOperator').addClass('d-none');
                    $('#BatalkanVerif').removeClass('d-none');

                    Swal.fire({
                        icon: 'success',
                        title: 'Verifikasi berhasil!',
                        text: 'Nomor Surat ' + nomorSurat + ' telah diverifikasi.',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            location.reload();
                        }
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Terjadi kesalahan:', error);
                }
            });
        });

        $('#TolakVerif').on('click', function() {
            var nomorSurat = $('#nomorSurat').val();
            var kodeSkpd = $('#kodeSkpd').val();
            var nomorRegister = $('#nomorRegister').val();
            $.ajax({
                url: '<?php echo e(route("verifikasi_admin.sertifikat.tolak")); ?>',
                type: 'POST',
                data: {
                    nomorSurat: nomorSurat,
                    kodeSkpd: kodeSkpd,
                    nomorRegister: nomorRegister,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    $('#BatalkanVerif').addClass('d-none');
                    $('#VerifOperator').addClass('d-none');
                    $('#TolakVerif').addClass('d-none');
                    Swal.fire({
                        icon: 'warning',
                        title: 'Peminjaman Ditolak!',
                        text: 'Nomor Surat ' + nomorSurat + ' Peminjaman Telah Ditolak',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            location.reload();
                        }
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Terjadi kesalahan:', error);
                }
            });
        });

        $('#BatalkanVerif').on('click', function() {
            var nomorSurat = $('#nomorSurat').val();

            $.ajax({
                url: '<?php echo e(route("verifikasi_admin.sertifikat.batalkan")); ?>',
                type: 'POST',
                data: {
                    nomorSurat: nomorSurat,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    $('#BatalkanVerif').addClass('d-none');
                    $('#VerifOperator').removeClass('d-none');

                    Swal.fire({
                        icon: 'warning',
                        title: 'Verifikasi dibatalkan!',
                        text: 'Nomor Surat ' + nomorSurat + ' telah dibatalkan verifikasinya.',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            location.reload();
                        }
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Terjadi kesalahan:', error);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-mantap\resources\views/verifikasi_admin/sertifikat/index.blade.php ENDPATH**/ ?>