<?php $__env->startSection('title', isset($barang_keluar) ? 'Edit Barang Keluar' : 'Tambah Barang Keluar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2><?php echo e(isset($barang_keluar) ? 'Edit Barang Keluar' : 'Tambah Barang Keluar'); ?></h2>
    </div>
    <div class="page-content">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show py-2">
                <div class="d-flex align-items-center">
                    <div class="font-35 text-white"><i class='bx bxs-message-square-x'></i>
                    </div>
                    <div class="ms-3">
                        <h6 class="mb-0 text-white">Pesan</h6>
                        <div class="text-white"><?php echo e(session('error')); ?></div>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <form id="barang_keluarForm"
                    action="<?php echo e(isset($barang_keluar) ? route('transaksi.barang_keluar.update', Crypt::encrypt($barang_keluar->id)) : route('transaksi.barang_keluar.store')); ?>"
                    method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($barang_keluar)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="row">
                        <!-- Kolom Pertama (Arab) -->
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="id_produk">Pilih Produk</label>
                                <select class="form-select <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="<?php echo e(isset($barang_keluar) ? 'id_produk_display' : 'id_produk'); ?>" dir="rtl"
                                    id="id_produk" style="width: 100%" <?php echo e(isset($barang_keluar) ? 'disabled' : ''); ?>>
                                    <?php if(isset($barang_keluar) && $barang_keluar->id_produk): ?>
                                        <option value="<?php echo e($barang_keluar->id_produk); ?>" selected>
                                            <?php echo e($barang_keluar->produk->judul ?? ''); ?> |
                                            <?php echo e($barang_keluar->produk->kategori ?? ''); ?> |
                                            <?php echo e($barang_keluar->produk->supplier_relasi->nama_supplier ?? ''); ?>

                                        </option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(isset($barang_keluar)): ?>
                                    <small class="text-muted">Produk tidak dapat diubah saat mode edit</small>
                                <?php endif; ?>

                                <?php if(isset($barang_keluar)): ?>
                                    <input type="hidden" name="id_produk" value="<?php echo e($barang_keluar->id_produk); ?>">
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Kolom Kedua (Indonesia) -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="kd_produk">Kode Produk</label>
                                <input type="text" class="form-control"
                                    style="background-color: #e9ecef; color: #6c757d;" name="kd_produk" id="kd_produk"
                                    value="<?php echo e(isset($barang_keluar) ? $barang_keluar->produk->kd_produk ?? '' : ''); ?>"
                                    readonly>
                            </div>

                            <div class="form-group">
                                <label for="penerbit">Penerbit</label>
                                <input type="text" class="form-control"
                                    style="background-color: #e9ecef; color: #6c757d;" name="penerbit" id="penerbit"
                                    value="<?php echo e(isset($barang_keluar) ? $barang_keluar->produk->penerbit ?? '' : ''); ?>"
                                    readonly>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="penulis">Penulis</label>
                                <input type="text" class="form-control"
                                    style="background-color: #e9ecef; color: #6c757d;" name="penulis" id="penulis"
                                    value="<?php echo e(isset($barang_keluar) ? $barang_keluar->produk->penulis ?? '' : ''); ?>"
                                    readonly>
                            </div>

                            <div class="form-group">
                                <label for="kategori">Kategori</label>
                                <input type="text" class="form-control"
                                    style="background-color: #e9ecef; color: #6c757d;" name="kategori" id="kategori"
                                    value="<?php echo e(isset($barang_keluar) ? $barang_keluar->produk->kategori ?? '' : ''); ?>"
                                    readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="supplier">Supplier</label>
                                <input type="text" class="form-control"
                                    style="background-color: #e9ecef; color: #6c757d;" name="supplier" id="supplier"
                                    value="<?php echo e(isset($barang_keluar) ? $barang_keluar->produk->supplier_relasi->nama_supplier ?? '' : ''); ?>"
                                    readonly>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="stok_saat_ini">Stok Saat Ini</label>
                                <input type="text" class="form-control"
                                    style="background-color: #e9ecef; color: #6c757d;" name="stok_saat_ini"
                                    id="stok_saat_ini"
                                    value="<?php echo e(isset($barang_keluar) ? $barang_keluar->produk->stok ?? '' : ''); ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="stok_keluar">Stok Keluar</label>
                        <input type="number" name="stok_keluar" id="stok_keluar" class="form-control"
                            value="<?php echo e(old('stok_keluar', $barang_keluar->stok_keluar ?? '')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="notes">Catatan (Opsional)</label>
                        <textarea name="notes" id="notes" class="form-control"><?php echo e(old('notes', $barang_keluar->notes ?? '')); ?></textarea>
                    </div>

                    <button type="submit"
                        class="btn btn-primary"><?php echo e(isset($barang_keluar) ? 'Update' : 'Tambah'); ?></button>
                    <a href="<?php echo e(route('transaksi.barang_keluar.index')); ?>" class="btn btn-warning">Kembali</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            // Inisialisasi Select2
            $('#id_produk').select2({
                theme: "bootstrap-5",
                width: "100%",
                placeholder: "Silahkan Pilih Produk",
                minimumInputLength: 0,
                dropdownParent: $('.card-body'),
                ajax: {
                    url: "<?php echo e(route('transaksi.barang_keluar.getproduk')); ?>",
                    dataType: 'json',
                    type: "POST",
                    delay: 250,
                    data: function(params) {
                        return {
                            q: $.trim(params.term),
                            _token: "<?php echo e(csrf_token()); ?>"
                        };
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data, function(item) {
                                return {
                                    id: item.id,
                                    text: item.text,
                                    kd_produk: item.kd_produk,
                                    penulis: item.penulis,
                                    kategori: item.kategori,
                                    penerbit: item.penerbit,
                                    supplier_nama: item.supplier_nama,
                                    stok: item.stok
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            // Ketika produk dipilih
            $('#id_produk').on('select2:select', function(e) {
                var data = e.params.data;

                // Isi semua field yang terkait
                $('#kd_produk').val(data.kd_produk);
                $('#penulis').val(data.penulis);
                $('#kategori').val(data.kategori);
                $('#penerbit').val(data.penerbit);
                $('#supplier').val(data.supplier_nama);
                $('#stok_saat_ini').val(data.stok);
            });

            <?php if(isset($barang_keluar) && $barang_keluar->id_produk): ?>
                // Jika dalam mode edit, isi data produk
                $.ajax({
                    url: "<?php echo e(route('transaksi.barang_keluar.getproduk')); ?>",
                    type: "POST",
                    data: {
                        id: "<?php echo e($barang_keluar->id_produk); ?>",
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            var product = data[0];
                            $('#kd_produk').val(product.kd_produk);
                            $('#penulis').val(product.penulis);
                            $('#kategori').val(product.kategori);
                            $('#penerbit').val(product.penerbit);
                            $('#supplier').val(product.supplier_nama);
                            $('#stok_saat_ini').val(product.stok);

                            // Update Select2 display
                            var $select = $('#id_produk');
                            var option = new Option(product.text, product.id, true, true);
                            $select.append(option).trigger('change');
                        }
                    }
                });
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/transaksi/barang_keluar/create.blade.php ENDPATH**/ ?>