<?php $__env->startSection('title', isset($customer) ? 'Edit Customer' : 'Tambah Customer'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3><?php echo e(isset($customer) ? 'Edit Customer' : 'Tambah Customer'); ?></h3>
    </div>
    <div class="page-content">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show">
                <div class="d-flex align-items-center">
                    <div class="font-35 text-white"><i class='bx bxs-message-square-x'></i></div>
                    <div class="ms-3">
                        <ul class="mb-0 text-white">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('message')): ?>
            <div
                class="alert alert-<?php echo e(session('message_type') ?? 'success'); ?> border-0 bg-<?php echo e(session('message_type') ?? 'success'); ?> alert-dismissible fade show">
                <div class="d-flex align-items-center">
                    <div class="font-35 text-white"><i class='bx bxs-check-circle'></i></div>
                    <div class="ms-3">
                        <h6 class="mb-0 text-white"><?php echo e(session('message_title') ?? 'Success'); ?></h6>
                        <div class="text-white"><?php echo e(session('message')); ?></div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                    aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form id="customerForm"
                    action="<?php echo e(isset($customer) ? route('kelola_data.customer.update', Crypt::encrypt($customer->id)) : route('kelola_data.customer.store')); ?>"
                    method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($customer)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group mb-3">
                                <label for="nama">Nama Customer</label>
                                <input type="text" name="nama" id="nama" class="form-control"
                                    value="<?php echo e(old('nama', $customer->nama ?? '')); ?>" placeholder="Masukkan nama customer"
                                    required>
                            </div>

                            <div class="form-group mb-3">
                                <label for="no_hp">Nomor HP</label>
                                <div class="input-group">
                                    <span class="input-group-text">+62</span>
                                    <input type="text" name="no_hp" id="no_hp" class="form-control"
                                        value="<?php echo e(old('no_hp', $customer->no_hp ?? '')); ?>" placeholder="81234567890"
                                        required>
                                </div>
                                <small class="text-muted">Contoh: 81234567890 (tanpa +62, 0, atau tanda baca)</small>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group mb-3">
                                <label for="alamat">Alamat</label>
                                <textarea name="alamat" id="alamat" class="form-control" rows="3" placeholder="Masukkan alamat lengkap"
                                    required><?php echo e(old('alamat', $customer->alamat ?? '')); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="<?php echo e(route('kelola_data.customer.index')); ?>" class="btn btn-secondary">
                            <i class="bx bx-arrow-back"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bx bx-save"></i> <?php echo e(isset($customer) ? 'Update' : 'Simpan'); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            // Format WhatsApp number input
            $('#no_hp').on('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '');
            });

            // Validate form before submit
            $('#customerForm').on('submit', function(e) {
                const noHp = $('#no_hp').val();
                if (noHp && noHp.startsWith('0')) {
                    e.preventDefault();
                    alert(
                        'Nomor HP tidak boleh dimulai dengan 0. Gunakan format contoh: 81234567890'
                    );
                    $('#no_hp').focus();
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/kelola_data/customer/create.blade.php ENDPATH**/ ?>