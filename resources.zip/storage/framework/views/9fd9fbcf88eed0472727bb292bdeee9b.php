<?php $__env->startSection('title', 'Edit Master TTD'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Edit Master SKPD</h3>
    </div>
    <div class="page-content">
        <div class="card">
            <div class="card-body">

                <form method="POST" action="<?php echo e(route('kelola_data.skpd.update', Crypt::encrypt($skpd->kodeSkpd))); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row mb-3">
                        <label for="nomorRegister" class="col-sm-2 form-label">Kode Skpd</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['kodeSkpd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="kodeSkpd" name="kodeSkpd"
                                   placeholder="Silahkan isi Kode Skpd"
                                   value="<?php echo e(old('kodeSkpd', $skpd->kodeSkpd)); ?>">
                            <?php $__errorArgs = ['kodeSkpd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="nib" class="col-sm-2 form-label">Nama Skpd</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['namaSkpd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="namaSkpd" name="namaSkpd"
                                   placeholder="Silahkan isi namaSkpd"
                                   value="<?php echo e(old('namaSkpd', $skpd->namaSkpd)); ?>">
                            <?php $__errorArgs = ['namaSkpd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>



                    <div class="row mb-3">
                        <div class="col-sm-12 text-end">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <a href="<?php echo e(route('kelola_data.skpd.index')); ?>" class="btn btn-warning">Kembali</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-mantap\resources\views/kelola_data/skpd/edit.blade.php ENDPATH**/ ?>