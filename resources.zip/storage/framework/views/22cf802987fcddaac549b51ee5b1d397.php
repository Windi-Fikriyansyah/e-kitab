<!DOCTYPE html>
<html>

<head>
    <title>Laporan Riwayat Produk</title>
    <style>
        @font-face {
            font-family: 'DejaVu Sans';
            font-style: normal;
            font-weight: normal;
            src: url(<?php echo e(storage_path('fonts/dejavu-sans.ttf')); ?>) format('truetype');
        }

        body {
            font-family: 'DejaVu Sans', Arial, sans-serif;
            font-size: 12px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .table th {
            background-color: #f2f2f2;
        }

        .info {
            margin-bottom: 20px;
        }

        .product-name {
            font-family: 'DejaVu Sans', Arial, sans-serif;
            font-size: 14px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h2>LAPORAN RIWAYAT PRODUK</h2>
    </div>

    <div class="info">
        <p><strong>Nama Produk:</strong> <span class="product-name"><?php echo e($produk->judul ?? '-'); ?></span></p>
        <p><strong>Periode:</strong> <?php echo e($tanggal_awal ?? '-'); ?> s/d <?php echo e($tanggal_akhir ?? '-'); ?></p>
        <p><strong>Filter Tipe:</strong> <?php echo e($filter_type ?? 'Semua'); ?></p>
        <p><strong>Filter User:</strong> <?php echo e($filter_user ?? 'Semua'); ?></p>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Jam</th>
                <th>Tipe</th>
                <th>Quantity</th>
                <th>User</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                    <td><?php echo e(date('H:i:s', strtotime($item->created_at))); ?></td>
                    <td><?php echo e($item->type); ?></td>
                    <td><?php echo e($item->qty); ?></td>
                    <td><?php echo e($item->user); ?></td>
                    <td><?php echo e($item->notes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH D:\e-arab\resources\views/exports/riwayat-pdf.blade.php ENDPATH**/ ?>