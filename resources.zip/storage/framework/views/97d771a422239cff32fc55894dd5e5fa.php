<?php $__env->startSection('title', 'Laporan Supplier'); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-content">
        <?php if(session('message')): ?>
            <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card radius-10">
            <div class="card-header">
                <div class="row align-items-end">
                    <div class="col-md-3">
                        <label for="tanggal_awal" class="form-label">Tanggal Awal</label>
                        <input type="date" class="form-control" id="tanggal_awal" name="tanggal_awal"
                            value="<?php echo e(date('Y-m-01')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="tanggal_akhir" class="form-label">Tanggal Akhir</label>
                        <input type="date" class="form-control" id="tanggal_akhir" name="tanggal_akhir"
                            value="<?php echo e(date('Y-m-d')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="produk" class="form-label">Produk</label>
                        <select class="form-select select2-produk" id="produk" name="produk">
                            <option value="">Semua Produk</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->kd_produk); ?>"><?php echo e($product->judul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12 d-flex gap-2">
                        <button type="button" class="btn btn-primary w-100" onclick="reloadTable()">
                            <i class="bi bi-filter"></i> Filter
                        </button>
                        <button type="button" class="btn btn-success w-100" onclick="exportExcel()">
                            <i class="bi bi-file-earmark-excel"></i> Export
                        </button>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body p-2">
                                <h6 class="mb-0">Total Quantity Terjual: <span id="total-qty" class="fw-bold">0</span>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body p-2">
                                <h6 class="mb-0">Total Nilai Terjual: <span id="total-nilai" class="fw-bold">Rp 0</span>
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle mb-0" id="laporansupplier" style="width: 100%">
                        <thead>
                            <tr>
                                <th>Kode Barang</th>
                                <th>Nama Barang</th>
                                <th>Supplier</th>
                                <th>Harga Beli</th>
                                <th>QTY Terjual</th>
                                <th>Total Terjual</th>
                                <th>Tanggal Transaksi Terakhir</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .select2-container .select2-selection--single {
            height: 38px;
            padding-top: 5px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.select2-produk').select2({
                placeholder: "Pilih Produk",
                theme: "bootstrap-5",
                allowClear: true
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            window.table = $('#laporansupplier').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('laporan.rekap_laporan_supplier.load')); ?>",
                    type: "POST",
                    data: function(d) {
                        d.tanggal_awal = $('#tanggal_awal').val();
                        d.tanggal_akhir = $('#tanggal_akhir').val();
                        d.produk = $('#produk').val();
                    },
                    dataSrc: function(json) {
                        $('#total-qty').text(json.total_qty || 0);
                        $('#total-nilai').text('Rp ' + (json.total_nilai ? parseInt(json.total_nilai)
                            .toLocaleString('id-ID') : 0));
                        return json.data;
                    }
                },
                pageLength: 10,
                searching: true,
                columns: [{
                        data: 'kd_produk',
                        name: 'produk.kd_produk'
                    },
                    {
                        data: 'judul',
                        name: 'produk.judul'
                    },
                    {
                        data: 'nama_supplier',
                        name: 'supplier.nama_supplier'
                    },
                    {
                        data: 'harga_modal',
                        name: 'produk.harga_modal',
                        render: function(data) {
                            return 'Rp ' + parseInt(data).toLocaleString('id-ID');
                        }
                    },
                    {
                        data: 'qty_terjual',
                        name: 'qty_terjual'
                    },
                    {
                        data: 'total_terjual',
                        name: 'total_terjual',
                        render: function(data) {
                            return 'Rp ' + parseInt(data).toLocaleString('id-ID');
                        }
                    },
                    {
                        data: 'last_transaction',
                        name: 'last_transaction',
                        render: function(data) {
                            return data ? new Date(data).toLocaleDateString('id-ID') : '-';
                        }
                    }
                ],
                columnDefs: [{
                    className: "dt-head-center",
                    targets: ['_all']
                }]
            });
        });

        function reloadTable() {
            window.table.ajax.reload();
        }

        function exportExcel() {
            let tanggal_awal = $('#tanggal_awal').val();
            let tanggal_akhir = $('#tanggal_akhir').val();
            let produk = $('#produk').val();

            window.location.href = "<?php echo e(route('laporan.rekap_laporan_supplier.export')); ?>?tanggal_awal=" + tanggal_awal +
                "&tanggal_akhir=" + tanggal_akhir + "&produk=" + produk;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/laporan/rekapSupplier/index.blade.php ENDPATH**/ ?>