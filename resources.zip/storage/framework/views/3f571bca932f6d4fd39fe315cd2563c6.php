<?php $__env->startSection('title', 'Detail Produk'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Detail Produk</h3>
    </div>
    <div class="page-content">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Informasi Produk</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Data Arab:</h6>
                        <table class="table table-bordered">
                            <tr>
                                <th width="30%">Kode Produk</th>
                                <td><?php echo e($produk->kd_produk); ?></td>
                            </tr>
                            <tr>
                                <th>الفنون</th>
                                <td><?php echo e($produk->kategori); ?></td>
                            </tr>
                            <tr>
                                <th>العنوان</th>
                                <td><?php echo e($produk->judul); ?></td>
                            </tr>
                            <tr>
                                <th>المؤلف</th>
                                <td><?php echo e($produk->penulis); ?></td>
                            </tr>
                            <tr>
                                <th>التحقيق والتعليق والاعتناء والتقديم</th>
                                <td><?php echo e($produk->editor); ?></td>
                            </tr>
                            <tr>
                                <th>الناشر</th>
                                <td><?php echo e($produk->penerbit); ?></td>
                            </tr>
                            <tr>
                                <th>التجليد</th>
                                <td><?php echo e($produk->cover); ?></td>
                            </tr>
                            <tr>
                                <th>الورق</th>
                                <td><?php echo e($produk->kertas); ?></td>
                            </tr>
                            <tr>
                                <th>الجودة</th>
                                <td><?php echo e($produk->kualitas); ?></td>
                            </tr>
                            <tr>
                                <th>التشكيل</th>
                                <td><?php echo e($produk->harakat); ?></td>
                            </tr>

                            
                            <?php if(isset($dynamicColumns)): ?>
                                <?php $__currentLoopData = $dynamicColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(property_exists($produk, $column) && !is_null($produk->$column)): ?>
                                        <tr>
                                            <th><?php echo e(ucfirst(str_replace('_', ' ', $column))); ?></th>
                                            <td><?php echo e($produk->$column); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Data Indonesia:</h6>
                        <table class="table table-bordered">
                            <tr>
                                <th width="30%">Judul</th>
                                <td><?php echo e($produk->judul_indo); ?></td>
                            </tr>
                            <tr>
                                <th>Kategori</th>
                                <td><?php echo e($produk->kategori_indo); ?></td>
                            </tr>
                            <tr>
                                <th>Penerbit</th>
                                <td><?php echo e($produk->penerbit_indo); ?></td>
                            </tr>
                            <tr>
                                <th>Cover</th>
                                <td><?php echo e($produk->cover_indo); ?></td>
                            </tr>
                            <tr>
                                <th>Kertas</th>
                                <td><?php echo e($produk->kertas_indo); ?></td>
                            </tr>
                            <tr>
                                <th>Kualitas</th>
                                <td><?php echo e($produk->kualitas_indo); ?></td>
                            </tr>
                            <tr>
                                <th>Harakat</th>
                                <td><?php echo e($produk->harakat_indo); ?></td>
                            </tr>

                            <tr>
                                <th>Penulis</th>
                                <td><?php echo e($produk->penulis_indo); ?></td>
                            </tr>
                            
                            <?php if(isset($dynamicColumns)): ?>
                                <?php $__currentLoopData = $dynamicColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $indoColumn = $column . '_indo';
                                    ?>
                                    <?php if(property_exists($produk, $indoColumn) && !is_null($produk->$indoColumn)): ?>
                                        <tr>
                                            <th><?php echo e(ucfirst(str_replace('_', ' ', $column))); ?></th>
                                            <td><?php echo e($produk->$indoColumn); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12">
                        <h6>Informasi Tambahan:</h6>
                        <table class="table table-bordered">
                            <tr>
                                <th width="20%">Supplier</th>
                                <td><?php echo e($produk->nama_supplier); ?> (<?php echo e($produk->telepon); ?>)</td>
                            </tr>
                            <tr>
                                <th>Halaman</th>
                                <td><?php echo e($produk->halaman); ?></td>
                            </tr>
                            <tr>
                                <th>Berat</th>
                                <td><?php echo e($produk->berat); ?></td>
                            </tr>
                            <tr>
                                <th>Ukuran</th>
                                <td><?php echo e($produk->ukuran); ?></td>
                            </tr>
                            <tr>
                                <th>Harga Modal</th>
                                <td>Rp <?php echo e(number_format($produk->harga_modal, 0, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <th>Harga Jual</th>
                                <td>Rp <?php echo e(number_format($produk->harga_jual, 0, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <th>Stok</th>
                                <td><?php echo e($produk->stok); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="text-center mt-3">
                    <a href="<?php echo e(route('kelola_data.produk.index')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/kelola_data/produk/show.blade.php ENDPATH**/ ?>