<footer style="position: absolute;bottom:0">
    <div class="footer clearfix mb-0 text-muted">
        
        
    </div>
</footer>
<?php /**PATH D:\e-mantap\resources\views/template/footer.blade.php ENDPATH**/ ?>