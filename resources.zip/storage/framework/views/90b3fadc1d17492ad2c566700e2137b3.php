<?php $__env->startSection('title', 'Data Produk'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Data Produk</h3>
    </div>
    <div class="page-content">
        <?php if(session('message')): ?>
            <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="modal fade" id="addColumnModal" tabindex="-1" aria-labelledby="addColumnModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addColumnModalLabel">Tambah Kolom Baru</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="addColumnForm">
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="column_name" class="form-label">Nama Kolom</label>
                                <input type="text" class="form-control" id="column_name" name="column_name" required>
                                <small class="text-muted">Gunakan format snake_case (contoh: nama_kolom)</small>
                            </div>
                            <div class="mb-3">
                                <label for="data_type" class="form-label">Tipe Data</label>
                                <select class="form-select" id="data_type" name="data_type" required>
                                    <option value="string">String (Text Pendek)</option>
                                    <option value="text">Text (Panjang)</option>
                                    <option value="integer">Integer (Angka)</option>
                                    <option value="decimal">Decimal (Desimal)</option>
                                    <option value="boolean">Boolean (True/False)</option>
                                    <option value="date">Date (Tanggal)</option>
                                    <option value="datetime">DateTime (Tanggal & Waktu)</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="barcodeModal" tabindex="-1" aria-labelledby="barcodeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="barcodeModalLabel">Barcode Produk</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <div id="barcodeContainer"></div>
                        <p id="barcodeText" class="mt-2"></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="button" class="btn btn-success" onclick="downloadBarcodeAsJPG()">Download
                            JPG</button>
                        <button type="button" class="btn btn-primary" onclick="printBarcode()">Cetak</button>
                    </div>
                </div>
            </div>
        </div>


        <div class="card radius-10">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <div>
                        <h5 class="card-title">Data Produk</h5>
                    </div>
                    <div class="dropdown ms-auto">
                        <button class="btn btn-info me-2" data-bs-toggle="modal" data-bs-target="#addColumnModal">
                            <i class="fas fa-plus"></i> Tambah Kolom
                        </button>
                        <a href="<?php echo e(route('kelola_data.produk.create')); ?>" class="btn btn-success">Tambah Produk</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-2">
                        <input type="text" class="form-control filter-input" placeholder="Filter Kd Produk"
                            data-column="kd_produk">
                    </div>
                    <div class="col-md-2">
                        <input type="text" class="form-control filter-input" placeholder="Filter Judul"
                            data-column="judul">
                    </div>
                    <div class="col-md-2">
                        <select class="form-select filter-select select2-penulis" data-column="penulis">
                            <option value="">Semua Penulis</option>
                            <?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penulis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($penulis->nama_arab); ?>"><?php echo e($penulis->nama_arab); ?> |
                                    <?php echo e($penulis->nama_indonesia); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select filter-select select2-kategori" data-column="kategori">
                            <option value="">Semua Kategori</option>
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kategori->nama_arab); ?>"><?php echo e($kategori->nama_arab); ?> |
                                    <?php echo e($kategori->nama_indonesia); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select filter-select select2-penerbit" data-column="penerbit">
                            <option value="">Semua Penerbit</option>
                            <?php $__currentLoopData = $penerbits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penerbit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($penerbit->nama_arab); ?>"><?php echo e($penerbit->nama_arab); ?> |
                                    <?php echo e($penerbit->nama_indonesia); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select filter-select select2-supplier" data-column="supplier">
                            <option value="">Semua Supplier</option>
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->nama_supplier); ?> |
                                    <?php echo e($supplier->telepon); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2 mt-2">
                        <input type="text" class="form-control filter-input" placeholder="Filter Stok"
                            data-column="stok">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0" id="produk" style="width: 100%">
                        <thead>
                            <tr>
                                <th>Gambar</th>
                                <th>Kd Produk</th>
                                <th>Judul</th>
                                <th style="display:none;">Penulis</th>
                                <th style="display:none;">Kategori</th>
                                <th style="display:none;">Penerbit</th>
                                <th style="display:none;">Supplier</th>
                                <th>Stok</th>
                                <th>Harga Modal</th>
                                <th style="display:none;">Harga Jual</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .right-gap {
            margin-right: 10px
        }

        .select2-container .select2-selection--single {
            height: 38px;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 36px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }

        #barcodeContainer svg {
            background-color: white;
            padding: 10px;
            border-radius: 5px;
            max-width: 100%;
            height: auto;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
    <script>
        window.printBarcode = function() {
            // Clone the barcode container for printing
            const printContent = document.getElementById('barcodeContainer').cloneNode(true);
            const printWindow = window.open('', '', 'width=600,height=600');

            printWindow.document.open();
            printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Cetak Barcode</title>
            <style>
                body {
                    text-align: center;
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                }
                svg {
                    margin: 20px auto;
                    display: block;
                }
                @media print {
                    body { padding: 0; }
                    button { display: none; }
                }
            </style>
        </head>
        <body>
            <h3>Barcode Produk</h3>
            <div id="printContent">${printContent.innerHTML}</div>
            <p>${document.getElementById('barcodeText').textContent}</p>
            <button onclick="window.print()">Cetak</button>
            <button onclick="downloadBarcodeImage()">Download JPG</button>
            <button onclick="window.close()">Tutup</button>
            <script>
                function downloadBarcodeImage() {
                    html2canvas(document.querySelector("#printContent")).then(canvas => {
                        const link = document.createElement('a');
                        link.download = 'barcode.jpg';
                        link.href = canvas.toDataURL('image/jpeg');
                        link.click();
                    });
                }
            <\/script>
        </body>
        </html>
    `);
            printWindow.document.close();
        };

        // Tambahkan fungsi untuk download JPG langsung dari modal
        function downloadBarcodeAsJPG() {
            html2canvas(document.querySelector("#barcodeContainer")).then(canvas => {
                const link = document.createElement('a');
                link.download = 'barcode_' + document.getElementById('barcodeText').textContent.replace(
                    /[^a-z0-9]/gi, '_').toLowerCase() + '.jpg';
                link.href = canvas.toDataURL('image/jpeg');
                link.click();
            });
        }


        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Inisialisasi Select2
            $('.select2-penulis').select2({
                theme: "bootstrap-5",
                placeholder: "Pilih Penulis",
                allowClear: true
            });
            $('.select2-kategori').select2({
                theme: "bootstrap-5",
                placeholder: "Pilih Kategori",
                allowClear: true
            });

            $('.select2-penerbit').select2({
                theme: "bootstrap-5",
                placeholder: "Pilih Penerbit",
                allowClear: true
            });

            $('.select2-supplier').select2({
                theme: "bootstrap-5",
                placeholder: "Pilih Supplier",
                allowClear: true
            });

            var table = $('#produk').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('kelola_data.produk.load')); ?>",
                    type: "POST",
                    data: function(d) {
                        // Tambahkan parameter filter untuk setiap kolom
                        $('.filter-input, .filter-select').each(function() {
                            if ($(this).val() != '') {
                                d.columns.find(col => col.data === $(this).data('column'))
                                    .search.value = $(this).val();
                            }
                        });
                    }
                },
                pageLength: 10,
                searching: true,
                scrollX: true,
                columns: [{
                        data: 'images',
                        name: 'images',
                        render: function(data) {
                            if (data) {
                                try {
                                    const images = JSON.parse(data);
                                    if (images.length > 0) {
                                        // Ambil gambar pertama
                                        const imageUrl = "<?php echo e(asset('storage/products')); ?>/" +
                                            images[0];
                                        return `<img src="${imageUrl}" class="product-thumbnail" alt="Product Image">`;
                                    }
                                } catch (e) {
                                    console.error('Error parsing images:', e);
                                }
                            }
                            return '<img src="<?php echo e(asset('assets/images/no-image.png')); ?>" class="product-thumbnail" alt="No Image">';
                        },
                        orderable: false,
                        searchable: false
                    }, {
                        data: 'kd_produk',
                    }, {
                        data: 'judul',
                    }, {
                        data: 'penulis',
                        visible: false
                    }, {
                        data: 'kategori',
                        visible: false
                    }, {
                        data: 'penerbit',
                        visible: false
                    }, {
                        data: 'supplier',
                        visible: false
                    },
                    {
                        data: 'stok',
                    }, {
                        data: 'harga_modal',
                        render: function(data) {
                            return data.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
                        }
                    }, {
                        data: 'harga_jual',
                        visible: false,
                        render: function(data) {
                            return data.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
                        }
                    },
                    {
                        data: 'aksi',
                        className: 'text-center text-nowrap'
                    }
                ],
                columnDefs: [{
                        className: "dt-head-center",
                        targets: ['_all']
                    },
                    {
                        className: "dt-body-center",
                        targets: [0, 1, 2, 7, 8, 10]
                    }
                ]
            });

            // Event listener untuk filter input
            $('.filter-input').keyup(function() {
                table.ajax.reload();
            });

            // Event listener untuk filter select
            $('.filter-select').change(function() {
                table.ajax.reload();
            });

            $(document).on('click', '.delete-btn', function(e) {
                e.preventDefault();
                var deleteUrl = $(this).data('url');

                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Produk ini akan dihapus!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: deleteUrl,
                            type: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire(
                                        'Terhapus!',
                                        'Produk berhasil dihapus.',
                                        'success'
                                    );
                                    table.ajax.reload();
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        'Gagal menghapus produk.',
                                        'error'
                                    );
                                }
                            },
                            error: function(xhr, status, error) {
                                Swal.fire(
                                    'Error!',
                                    'Gagal menghapus produk.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });

            $(document).on('click', '.barcode-btn', function() {
                var kdProduk = $(this).data('kd');
                var judulProduk = $(this).data('judul');

                $('#barcodeText').text(kdProduk + ' - ' + judulProduk);
                $('#barcodeContainer').html('<svg id="barcode"></svg>');

                // Generate barcode
                JsBarcode("#barcode", kdProduk, {
                    format: "CODE128",
                    lineColor: "#000",
                    width: 2,
                    height: 50,
                    displayValue: false
                });

                $('#barcodeModal').modal('show');
            });


            $('#addColumnForm').submit(function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Kolom baru akan ditambahkan ke database",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, tambahkan!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "<?php echo e(route('kelola_data.produk.addColumn')); ?>",
                            type: "POST",
                            data: $(this).serialize(),
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire(
                                        'Berhasil!',
                                        response.message,
                                        'success'
                                    );
                                    $('#addColumnModal').modal('hide');
                                    table.ajax.reload();
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        response.message,
                                        'error'
                                    );
                                }
                            },
                            error: function(xhr) {
                                Swal.fire(
                                    'Error!',
                                    xhr.responseJSON.message ||
                                    'Gagal menambahkan kolom',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-arab\resources\views/kelola_data/produk/index.blade.php ENDPATH**/ ?>