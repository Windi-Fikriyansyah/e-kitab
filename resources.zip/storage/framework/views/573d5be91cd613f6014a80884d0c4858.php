<?php $__env->startSection('title', 'Tambah BPKB'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2><?php echo e(isset($product) ? 'Edit Produk' : 'Tambah Produk'); ?></h2>
    </div>
    <div class="page-content">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('message')): ?>
            <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show py-2">
                <div class="d-flex align-items-center">
                    <div class="font-35 text-white"><i class='bx bxs-message-square-x'></i>
                    </div>
                    <div class="ms-3">
                        <h6 class="mb-0 text-white">Error</h6>
                        <div class="text-white"><?php echo e(session('message')); ?></div>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <form id="productForm" action="<?php echo e(isset($product) ? route('kelola_data.products.update', $product->id) : route('kelola_data.products.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($product)): ?>
                        <?php echo method_field('POST'); ?>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="barcode">Barcode</label>
                        <input type="text" name="barcode" id="barcode" class="form-control" value="<?php echo e(old('barcode', $product->barcode ?? '')); ?>" placeholder="Scan atau ketik barcode">
                    </div>

                    <div class="form-group">
                        <label for="name">Nama Produk</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $product->name ?? '')); ?>" placeholder="Nama produk">
                    </div>

                    <div class="form-group">
                        <label for="category">Kategori</label>
                        <input type="text" name="category" id="category" class="form-control" value="<?php echo e(old('category', $product->category ?? '')); ?>" placeholder="Kategori produk">
                    </div>

                    <div class="form-group">
                        <label for="purchase_price_display">Harga Beli</label>
                        <input type="text" id="purchase_price_display" class="form-control" value="<?php echo e(old('purchase_price', isset($product) ? number_format($product->purchase_price, 0, ',', '.') : '')); ?>" placeholder="0">
                        <input type="hidden" name="purchase_price" id="purchase_price" value="<?php echo e(old('purchase_price', $product->purchase_price ?? '')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="selling_price_display">Harga Jual/Satuan</label>
                        <input type="text" id="selling_price_display" class="form-control" value="<?php echo e(old('selling_price', isset($product) ? number_format($product->selling_price, 0, ',', '.') : '')); ?>" placeholder="0">
                        <input type="hidden" name="selling_price" id="selling_price" value="<?php echo e(old('selling_price', $product->selling_price ?? '')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="stock">Stok</label>
                        <input type="number" name="stock" id="stock" class="form-control" value="<?php echo e(old('stock', $product->stock ?? '')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="satuan">Satuan</label>
                        <input type="text" name="satuan" id="satuan" class="form-control" value="<?php echo e(old('satuan', $product->satuan ?? '')); ?>" placeholder="Satuan produk">
                    </div>

                    <div class="form-group">
                        <label for="photo">Foto Produk</label>
                        <input type="file" name="photo" id="photo" class="form-control">
                        <?php if(isset($product) && $product->photo): ?>
                            <div class="mt-2">
                                <img src="<?php echo e(asset('storage/' . $product->photo)); ?>" alt="Foto Produk" width="150">
                            </div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(isset($product) ? 'Update' : 'Tambah'); ?></button>
                    <a href="<?php echo e(route('kelola_data.products.index')); ?>" class="btn btn-warning">Kembali</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Function to format number with thousand separator
            function formatNumber(number) {
                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            }

            // Function to clean number format (remove separators)
            function cleanNumber(number) {
                return number.replace(/\./g, '');
            }

            // Handle purchase price input
            $('#purchase_price_display').on('input', function() {
                let value = cleanNumber($(this).val());
                if (value !== '') {
                    // Update hidden input with clean number
                    $('#purchase_price').val(value);
                    // Update display input with formatted number
                    $(this).val(formatNumber(value));
                } else {
                    $('#purchase_price').val('');
                    $(this).val('');
                }
            });

            // Handle selling price input
            $('#selling_price_display').on('input', function() {
                let value = cleanNumber($(this).val());
                if (value !== '') {
                    // Update hidden input with clean number
                    $('#selling_price').val(value);
                    // Update display input with formatted number
                    $(this).val(formatNumber(value));
                } else {
                    $('#selling_price').val('');
                    $(this).val('');
                }
            });

            // Only allow numbers and dots in price inputs
            $('.form-control[id$="_display"]').on('keypress', function(e) {
                if (!/[\d.]/.test(String.fromCharCode(e.which))) {
                    e.preventDefault();
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kasir\resources\views/kelola_data/products/create.blade.php ENDPATH**/ ?>